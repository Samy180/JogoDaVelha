import pygame
from pygame.locals import *
from sys import exit

pygame.init()
tela = pygame.display.set_mode((600, 600))
pygame.display.set_caption("Jogo da Velha")


q1 = Rect((0,0), (200,200))
q2 = Rect((200,0), (200,200))
q3 = Rect((400,0), (200,200))
q4 = Rect((0,200), (200,200))
q5 = Rect((200,200), (200,200))
q6 = Rect((400,200), (200,200))
q7 = Rect((0,400), (200,200))
q8 = Rect((200,400), (200,200))
q9 = Rect((400,400), (200,200))

rec = [
    q1,q2,q3,q4,
    q5,q6,q7,q7,q8,q9,
]

estado = 'Jogando'
vez = 'Jogador1'
escolha = 'X'
espaço = 0
tabuleiro = [
    0, 1, 2,
    3, 4, 5,
    6, 7, 8
]


def desenhar_tabu():
    pygame.draw.line(tela, (255, 255, 255),(200,0), (200,600),10)
    pygame.draw.line(tela, (255, 255, 255),(400,0), (400,600),10)
    pygame.draw.line(tela, (255, 255, 255),(0,200), (600,200),10)
    pygame.draw.line(tela, (255, 255, 255),(0,400), (600,400),10)

def desenhar_peça(pos):
    global vez
    x, y = pos
    if vez == 'Jogador2':
        img = pygame.image.load('c:/bolinha.png').convert_alpha()
        imgR = pygame.transform.scale(img, (100, 100))
        tela.blit(imgR, (x - 50, y - 50))
    else:
        img = pygame.image.load('c:/X.png').convert_alpha()
        imgR = pygame.transform.scale(img, (100, 100))
        tela.blit(imgR, (x - 50, y - 50))

def testa_pos():
    for p in rec:
        if e.type == MOUSEBUTTONDOWN and p.collidepoint(mouse_pos):
            if p == q1:
                confirmar(0, [100, 100])
            if p == q2:
                confirmar(1, [300, 100])
            if p == q3:
                confirmar(2, [500, 100])
            if p == q4:
                confirmar(3, [100, 300])
            if p == q5:
                confirmar(4, [300, 300])
            if p == q6:
                confirmar(5, [500, 300])
            if p == q7:
                confirmar(6, [100, 500])
            if p == q8:
                confirmar(7, [300, 500])
            if p == q9:
                confirmar(8, [500, 500])

def confirmar(indice, pos):
    global escolha, vez, espaço
    if tabuleiro[indice] == 'X':
        print('X')
    elif tabuleiro [indice] == 'O':
        print('O')
    else:
        tabuleiro[indice] = escolha
        desenhar_peça(pos)
        print (tabuleiro)
        if vez == 'Jogador1':
            vez = 'Jogador2'
        else:
            vez = 'Jogador1'
        espaço +=1

def teste_vitoria(l):
    return ((tabuleiro[0] == l and tabuleiro[1] == l and tabuleiro[2] == l) or
        (tabuleiro[3] == l and tabuleiro[4] == l and tabuleiro[5] == l) or
        (tabuleiro[6] == l and tabuleiro[7] == l and tabuleiro[8] == l) or
        (tabuleiro[0] == l and tabuleiro[3] == l and tabuleiro[6] == l) or
        (tabuleiro[1] == l and tabuleiro[4] == l and tabuleiro[7] == l) or
        (tabuleiro[2] == l and tabuleiro[5] == l and tabuleiro[8] == l) or
        (tabuleiro[0] == l and tabuleiro[4] == l and tabuleiro[8] == l) or        
        (tabuleiro[2] == l and tabuleiro[4] == l and tabuleiro[6] == l))

def texto_vitoria(v):
    arial = pygame.font.SysFont('arial',50)
    mensagem = 'Jogador {} Venceu'.format(v)

    if v == 'Empate':
        mens_vitoria = arial.render('Deu Velha', True, (0, 0, 255), 0)
        tela.blit(mens_vitoria, (208, 265))
    else:
        mens_vitoria = arial.render(mensagem, True, (0, 0, 255), 0)
        tela.blit(mens_vitoria, (125, 265))

def reset():
        global escolha, estado, vez, tabuleiro, espaço
        estado = 'Jogando'
        vez = 'Jogador1'
        escolha = 'X'
        espaço = 0
        tabuleiro = [
            0, 1, 2,
            3, 4, 5,
            6, 7, 8
        ]
        tela.fill(0)

while True:
    mouse_pos = pygame.mouse.get_pos()
    if estado == 'Jogando':
        desenhar_tabu()

        for e in pygame.event.get():
            if e.type == QUIT:
                pygame.quit()
                exit()
            if e.type == MOUSEBUTTONDOWN:
                if vez == 'Jogador1':
                    escolha = "X"
                    testa_pos()
                else:
                    escolha = 'O'
                    testa_pos()
            
        if teste_vitoria('X'):
            print('X Venceu')
            texto_vitoria('X')
            estado = 'Reset'

        if teste_vitoria('O'):
            print('O Venceu')
            texto_vitoria('O')
            estado = "Reset"

        elif espaço >=9:
            print ('Empate')
            texto_vitoria('Empate')
            estado = 'Reset'

    else:
        for i in pygame.event.get():
            if i.type == QUIT:
                pygame.quit()
                exit()
            if i.type == MOUSEBUTTONDOWN:
                reset()
                desenhar_tabu()
    pygame.display.flip()
